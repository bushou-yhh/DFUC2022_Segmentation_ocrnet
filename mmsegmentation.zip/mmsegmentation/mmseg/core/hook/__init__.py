# Copyright (c) OpenMMLab. All rights reserved.
from .wandblogger_hook import MMSegWandbHook

__all__ = ['MMSegWandbHook']
