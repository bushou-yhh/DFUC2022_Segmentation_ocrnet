# Copyright (c) OpenMMLab. All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import ConvModule
import numpy as np
import cv2
from PIL import Image

from mmcv.runner import BaseModule, auto_fp16, force_fp32
from mmseg.ops import resize
from ..builder import HEADS
from ..utils import SelfAttentionBlock as _SelfAttentionBlock
from .cascade_decode_head import BaseCascadeDecodeHead
from ..losses import accuracy
from mmcv.cnn.bricks import (NORM_LAYERS, DropPath, build_activation_layer,
                             build_norm_layer)
from mmcv.runner import BaseModule
from functools import partial
from scipy.ndimage.morphology import distance_transform_edt
from ..losses import binary_cross_entropy

def mask_to_onehot(mask, num_classes):
    """
    Converts a segmentation mask (H,W) to (K,H,W) where the last dim is a one
    hot encoding vector
    """
    _mask = [mask == (i + 1) for i in range(num_classes)]
    return np.array(_mask).astype(np.uint8)

def onehot_to_mask(mask):
    """
    Converts a mask (K,H,W) to (H,W)
    """
    _mask = np.argmax(mask, axis=0)
    _mask[_mask != 0] += 1
    return _mask

def onehot_to_multiclass_edges(mask, radius, num_classes):
    """
    Converts a segmentation mask (K,H,W) to an edgemap (K,H,W)
    """
    if radius < 0:
        return mask
    
    # We need to pad the borders for boundary conditions
    mask_pad = np.pad(mask, ((0, 0), (1, 1), (1, 1)), mode='constant', constant_values=0)
    
    channels = []
    for i in range(num_classes):
        dist = distance_transform_edt(mask_pad[i, :])+distance_transform_edt(1.0-mask_pad[i, :])
        dist = dist[1:-1, 1:-1]
        dist[dist > radius] = 0
        dist = (dist > 0).astype(np.uint8)
        channels.append(dist)
        
    return np.array(channels)

def onehot_to_binary_edges(mask, radius, num_classes):
    """
    Converts a segmentation mask (K,H,W) to a binary edgemap (H,W)
    """
    
    if radius < 0:
        return mask
    
    # We need to pad the borders for boundary conditions
    mask_pad = np.pad(mask, ((0, 0), (1, 1), (1, 1)), mode='constant', constant_values=0)
    
    edgemap = np.zeros(mask.shape[1:])

    for i in range(num_classes):
        dist = distance_transform_edt(mask_pad[i, :])+distance_transform_edt(1.0-mask_pad[i, :])
        dist = dist[1:-1, 1:-1]
        dist[dist > radius] = 0
        edgemap += dist
    edgemap = np.expand_dims(edgemap, axis=0)    
    edgemap = (edgemap > 0).astype(np.uint8)
    return edgemap




class ConvNeXtBlock(BaseModule):
    """ConvNeXt Block.
    Args:
        in_channels (int): The number of input channels.
        norm_cfg (dict): The config dict for norm layers.
            Defaults to ``dict(type='LN2d', eps=1e-6)``.
        act_cfg (dict): The config dict for activation between pointwise
            convolution. Defaults to ``dict(type='GELU')``.
        mlp_ratio (float): The expansion ratio in both pointwise convolution.
            Defaults to 4.
        linear_pw_conv (bool): Whether to use linear layer to do pointwise
            convolution. More details can be found in the note.
            Defaults to True.
        drop_path_rate (float): Stochastic depth rate. Defaults to 0.
        layer_scale_init_value (float): Init value for Layer Scale.
            Defaults to 1e-6.
    Note:
        There are two equivalent implementations:
        1. DwConv -> LayerNorm -> 1x1 Conv -> GELU -> 1x1 Conv;
           all outputs are in (N, C, H, W).
        2. DwConv -> LayerNorm -> Permute to (N, H, W, C) -> Linear -> GELU
           -> Linear; Permute back
        As default, we use the second to align with the official repository.
        And it may be slightly faster.
    """

    def __init__(self,
                 in_channels,
                 norm_cfg=dict(type='LN2d', eps=1e-6),
                 act_cfg=dict(type='GELU'),
                 mlp_ratio=4.,
                 linear_pw_conv=True,
                 drop_path_rate=0.,
                 layer_scale_init_value=1e-6):
        super().__init__()
        self.depthwise_conv = nn.Conv2d(
            in_channels,
            in_channels,
            kernel_size=7,
            padding=3,
            groups=in_channels)

        self.linear_pw_conv = linear_pw_conv
        self.norm = build_norm_layer(norm_cfg, in_channels)[1]

        mid_channels = int(mlp_ratio * in_channels)
        if self.linear_pw_conv:
            # Use linear layer to do pointwise conv.
            pw_conv = nn.Linear
        else:
            pw_conv = partial(nn.Conv2d, kernel_size=1)

        self.pointwise_conv1 = pw_conv(in_channels, mid_channels)
        self.act = build_activation_layer(act_cfg)
        self.pointwise_conv2 = pw_conv(mid_channels, in_channels)

        self.gamma = nn.Parameter(
            layer_scale_init_value * torch.ones((in_channels)),
            requires_grad=True) if layer_scale_init_value > 0 else None

        self.drop_path = DropPath(
            drop_path_rate) if drop_path_rate > 0. else nn.Identity()

    def forward(self, x):
        shortcut = x
        x = self.depthwise_conv(x)
        x = self.norm(x)

        if self.linear_pw_conv:
            x = x.permute(0, 2, 3, 1)  # (N, C, H, W) -> (N, H, W, C)

        x = self.pointwise_conv1(x)
        x = self.act(x)
        x = self.pointwise_conv2(x)

        if self.linear_pw_conv:
            x = x.permute(0, 3, 1, 2)  # permute back

        if self.gamma is not None:
            x = x.mul(self.gamma.view(1, -1, 1, 1))

        x = shortcut + self.drop_path(x)
        return x

# class _AtrousSpatialPyramidPoolingModule(nn.Module):
#     '''
#     operations performed:
#       1x1 x depth
#       3x3 x depth dilation 6
#       3x3 x depth dilation 12
#       3x3 x depth dilation 18
#       image pooling
#       concatenate all together
#       Final 1x1 conv
#     '''

#     def __init__(self, in_dim, reduction_dim=256, output_stride=16, rates=[6, 12, 18],  norm_cfg=dict(type='SyncBN', requires_grad=True)):
#         super(_AtrousSpatialPyramidPoolingModule, self).__init__()

#         # Check if we are using distributed BN and use the nn from encoding.nn
#         # library rather than using standard pytorch.nn

#         if output_stride == 8:
#             rates = [2 * r for r in rates]
#         elif output_stride == 16:
#             pass
#         else:
#             raise 'output stride of {} not supported'.format(output_stride)

#         self.features = []
#         # 1x1
#         # self.features.append(
#         #     nn.Sequential(nn.Conv2d(in_dim, reduction_dim, kernel_size=1, bias=False),
#         #                   Norm2d(reduction_dim), nn.ReLU(inplace=True)))
#         self.features.append(ConvModule(in_channels=in_dim,
#                                         out_channels=reduction_dim, kernel_size=1,
#                                         bias=False,norm_cfg=norm_cfg, inplace=True))
#         # other rates
#         for r in rates:
#             # self.features.append(nn.Sequential(
#             #     nn.Conv2d(in_dim, reduction_dim, kernel_size=3,
#             #               dilation=r, padding=r, bias=False),
#             #     Norm2d(reduction_dim),
#             #     nn.ReLU(inplace=True)
#             # ))
#             self.features.append(ConvModule(in_channels=in_dim,
#                                         out_channels=reduction_dim, kernel_size=3,
#                                         dilation=r, padding=r,bias=False,
#                                         norm_cfg=norm_cfg, inplace=True))
#         self.features = torch.nn.ModuleList(self.features)

#         # img level features
#         self.img_pooling = nn.AdaptiveAvgPool2d(1)
#         # self.img_conv = nn.Sequential(
#         #     nn.Conv2d(in_dim, reduction_dim, kernel_size=1, bias=False),
#         #     Norm2d(reduction_dim), nn.ReLU(inplace=True))
#         self.img_conv = ConvModule(in_channels=in_dim,
#                                         out_channels=reduction_dim, kernel_size=1,
#                                         bias=False,norm_cfg=norm_cfg, inplace=True)
#         # self.edge_conv = nn.Sequential(
#         #     nn.Conv2d(1, reduction_dim, kernel_size=1, bias=False),
#         #     Norm2d(reduction_dim), nn.ReLU(inplace=True))
#         self.edge_conv = ConvModule(in_channels=in_dim,
#                                         out_channels=reduction_dim, kernel_size=1,
#                                         bias=False,norm_cfg=norm_cfg, inplace=True)     

#     def forward(self, x, edge):
#         x_size = x.size()

#         img_features = self.img_pooling(x)
#         img_features = self.img_conv(img_features)
#         img_features = F.interpolate(img_features, x_size[2:],
#                                      mode='bilinear',align_corners=True)
#         out = img_features

#         edge_features = F.interpolate(edge, x_size[2:],
#                                       mode='bilinear',align_corners=True)
#         edge_features = self.edge_conv(edge_features)
#         out = torch.cat((out, edge_features), 1)

#         for f in self.features:
#             y = f(x)
#             out = torch.cat((out, y), 1)
#         return out

class SpatialGatherModule(nn.Module):
    """Aggregate the context features according to the initial predicted
    probability distribution.

    Employ the soft-weighted method to aggregate the context.
    """

    def __init__(self, scale):
        super(SpatialGatherModule, self).__init__()
        self.scale = scale

    def forward(self, feats, probs):
        """Forward function."""
        batch_size, num_classes, height, width = probs.size()
        channels = feats.size(1)
        probs = probs.view(batch_size, num_classes, -1)
        feats = feats.view(batch_size, channels, -1)
        # import pdb;pdb.set_trace()
        # [batch_size, height*width, num_classes]
        feats = feats.permute(0, 2, 1)
        # [batch_size, channels, height*width]
        probs = F.softmax(self.scale * probs, dim=2)
        
        # [batch_size, channels, num_classes]
        ocr_context = torch.matmul(probs, feats)  # Object Region Representations
        ocr_context = ocr_context.permute(0, 2, 1).contiguous().unsqueeze(3)
        return ocr_context


class ObjectAttentionBlock(_SelfAttentionBlock):
    """Make a OCR used SelfAttentionBlock."""

    def __init__(self, in_channels, channels, scale, conv_cfg, norm_cfg,
                 act_cfg):
        if scale > 1:
            query_downsample = nn.MaxPool2d(kernel_size=scale)
        else:
            query_downsample = None
        super(ObjectAttentionBlock, self).__init__(
            key_in_channels=in_channels,
            query_in_channels=in_channels,
            channels=channels,
            out_channels=in_channels,
            share_key_query=False,
            query_downsample=query_downsample,
            key_downsample=None,
            key_query_num_convs=2,
            key_query_norm=True,
            value_out_num_convs=1,
            value_out_norm=True,
            matmul_norm=True,
            with_out=True,
            conv_cfg=conv_cfg,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg)
        self.bottleneck = ConvModule(
            in_channels * 2,
            in_channels,
            1,
            conv_cfg=self.conv_cfg,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg)

    def forward(self, query_feats, key_feats):
        """Forward function."""
        context = super(ObjectAttentionBlock,
                        self).forward(query_feats, key_feats)
        output = self.bottleneck(torch.cat([context, query_feats], dim=1))
        if self.query_downsample is not None:
            output = resize(query_feats)

        return output


@HEADS.register_module()
class OCRHead_EDGE(BaseCascadeDecodeHead):
    """Object-Contextual Representations for Semantic Segmentation.

    This head is the implementation of `OCRNet
    <https://arxiv.org/abs/1909.11065>`_.

    Args:
        ocr_channels (int): The intermediate channels of OCR block.
        scale (int): The scale of probability map in SpatialGatherModule in
            Default: 1.
    """

    def __init__(self, ocr_channels, scale=1, **kwargs):
        super(OCRHead_EDGE, self).__init__(**kwargs)
        self.ocr_channels = ocr_channels
        self.scale = scale
        self.object_context_block = ObjectAttentionBlock(
            self.channels,
            self.ocr_channels,
            self.scale,
            conv_cfg=self.conv_cfg,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg)
        self.spatial_gather_module = SpatialGatherModule(self.scale)

        self.bottleneck = ConvModule(
            self.in_channels,
            self.channels,
            3,
            padding=1,
            conv_cfg=self.conv_cfg,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg)
        # import ipdb;ipdb.set_trace()
        
        self.bc= ConvModule(
            self.channels,
            self.channels//8,
            3,
            padding=1,
            conv_cfg=self.conv_cfg,
            norm_cfg=self.norm_cfg,
            act_cfg=self.act_cfg)
        
        self.fuse= ConvModule(
            self.channels//8+4,
            1,
            1,
            padding=0,
            conv_cfg=self.conv_cfg,
            norm_cfg=self.norm_cfg,
            act_cfg={'type': 'Sigmoid'})
        # self.dsn0= nn.Conv2d(256, 1, 1)
        # self.dsn1= nn.Conv2d(512, 1, 1)
        # self.dsn2= nn.Conv2d(1024, 1, 1)
        # self.dsn3= nn.Conv2d(2048, 1, 1)
        
        # self.d0 = nn.Conv2d(256, 64, 1)
        # self.convnextblock1 = ConvNeXtBlock(64)
        # self.d1 = nn.Conv2d(64, 32, 1)
        # self.convnextblock2 = ConvNeXtBlock(32)
        # self.d2 = nn.Conv2d(32, 16, 1)
        # self.convnextblock3 = ConvNeXtBlock(16)
        # self.d3 = nn.Conv2d(16, 8, 1)       
        # self.fuse = nn.Conv2d(8, 1, kernel_size=1, padding=0, bias=False) 
        
        
        # self.d1 = nn.Conv2d(2, 1, 1)
        # self.cw = nn.Conv2d(2, 1, 1)
        # self.cw2 = nn.Conv2d(1, 1, kernel_size=3, stride=2, padding=1, bias=False)
              
        # # self.gate1 = GatedSpatialConv2d(32, 32)
        # # self.gate2 = GatedSpatialConv2d(16, 16)
        # # self.gate3 = GatedSpatialConv2d(8, 8)
        
        
        
        # self.sigmoid = nn.Sigmoid()

    def forward(self, inputs, prev_output,mode="val"):
        """Forward function."""



        # import pdb; pdb.set_trace()       # import pdb; pdb.set_trace()
             
        # edge_out = self.sigmoid(cs)
        # cat = torch.cat((edge_out, canny), dim=1)
        # acts = self.cw1(cat)
        # acts = self.cw2(acts)
    
        # acts = self.sigmoid(acts)
            
        
        
        x = self._transform_inputs(inputs)
        feats = self.bottleneck(x)
        edgef = feats
        edgef = self.bc(edgef)
        
        
        context = self.spatial_gather_module(feats, prev_output)
        
        object_context = self.object_context_block(feats, context)
        output = self.cls_seg(object_context)
        # import ipdb;ipdb.set_trace()
        output1 = prev_output
        output2 = output
        edge_out = torch.concat((edgef, output1, output2), dim=1)
        edge_out = self.fuse(edge_out)
        
        # img_size = img.size()
        # im_arr = img.cpu().numpy().transpose((0,2,3,1)).astype(np.uint8)
        # canny = np.zeros((img_size[0], 1, img_size[2], img_size[3]))
        # for i in range(img_size[0]):
        #     canny[i] = cv2.Canny(im_arr[i],10,100)  
        # canny = torch.from_numpy(canny).cuda().float()     
        
        # edge = F.interpolate(self.d1(output), img_size[2:], 
        #                     mode='bilinear', align_corners=True)
        # edge_out = edge.sigmoid()
        
    #     edge_out =edge_out[:, 0] >0.6
    #     edge_out = edge_out.long()
    #     canny = np.zeros((img_size[0], 1, img_size[2], img_size[3]))
    #     for i in range(img_size[0]):
    #         canny[i] = edge_out[i].cpu().numpy()
    #         canny[i]= mask_to_onehot(canny[i], 1)
    # # import pdb;pdb.set_trace()
    #         canny[i] = onehot_to_binary_edges(canny[i], 2, 1)
    #         # canny = cv2.Canny(canny,0,1) 
    #         color_seg = np.zeros((img_size[2], img_size[3], 1), dtype=np.uint8)
    #         # import ipdb;ipdb.set_trace()
    #         color_seg[canny[i][0] == 1, :] = 255
    #         outputcanny = "canny/{}_canny.png".format(img_metas[0]['ori_filename'].split('.')[0])
            # outputimg = "canny/{}".format(img_metas[0]['ori_filename'])
           
            # img_ = img[i].cpu().numpy().transpose((1,2,0))
            # import pdb;pdb.set_trace()
            # cv2.imwrite(outputcanny, color_seg[:, :, 0])
            # cv2.imwrite(outputimg, img_)
        # canny = torch.from_numpy(canny).cuda().float()        
        # cat = torch.cat((edge, canny), dim=1)
        # acts = self.cw(cat)
        # acts = self.sigmoid(acts)


        if mode == "train":
            return output, edge_out
        else:
            
            return output


    def forward_train(self, inputs, prev_output, img_metas, gt_semantic_seg,
                      train_cfg):
        """Forward function for training.
        Args:
            inputs (list[Tensor]): List of multi-level img features.
            prev_output (Tensor): The output of previous decode head.
            img_metas (list[dict]): List of image info dict where each dict
                has: 'img_shape', 'scale_factor', 'flip', and may also contain
                'filename', 'ori_shape', 'pad_shape', and 'img_norm_cfg'.
                For details on the values of these keys see
                `mmseg/datasets/pipelines/formatting.py:Collect`.
            gt_semantic_seg (Tensor): Semantic segmentation masks
                used if the architecture supports semantic segmentation task.
            train_cfg (dict): The training config.

        Returns:
            dict[str, Tensor]: a dictionary of loss components
        """
        seg_logits, edge_logits = self.forward(inputs, prev_output, mode='train')
        
        
        losses = self.losses(seg_logits, gt_semantic_seg, edge_logits, img_metas)

        return losses
    
    
    def forward_test(self, inputs, prev_output, img_metas, test_cfg):
        """Forward function for testing.

        Args:
            inputs (list[Tensor]): List of multi-level img features.
            prev_output (Tensor): The output of previous decode head.
            img_metas (list[dict]): List of image info dict where each dict
                has: 'img_shape', 'scale_factor', 'flip', and may also contain
                'filename', 'ori_shape', 'pad_shape', and 'img_norm_cfg'.
                For details on the values of these keys see
                `mmseg/datasets/pipelines/formatting.py:Collect`.
            test_cfg (dict): The testing config.

        Returns:
            Tensor: Output segmentation map.
        """
        return self.forward(inputs, prev_output)
    
    @force_fp32(apply_to=('seg_logit', 'edge_logits'))
    def losses(self, seg_logit, seg_label, edge_logits, img_metas):
        """Compute segmentation loss."""
        loss = dict()
        # import pdb;pdb.set_trace()
        seg_logit = resize(
            input=seg_logit,
            size=seg_label.shape[2:],
            mode='bilinear',
            align_corners=self.align_corners)
        edge_logits = resize(
            input=edge_logits,
            size=seg_label.shape[2:],
            mode='bilinear',
            align_corners=self.align_corners)
        if self.sampler is not None:
            seg_weight = self.sampler.sample(seg_logit, seg_label)
        else:
            seg_weight = None
            
        img_size = seg_label.shape
        mask = seg_label.clone()
        mask = mask.cpu()
        mask_size = mask.size()
        edgemap = np.zeros((mask_size[0],  mask_size[2], mask_size[3]))
        edgepreds = edge_logits.clone().detach().cpu()
        for i in range(mask_size[0]):
            edgemap[i] = mask[i][0].numpy()
            edgepred = edgepreds[i][0]
            # import ipdb;ipdb.set_trace()
            edgepred =edgepred > 0.6
            edgepred = edgepred.long()
            edgepred = edgepred.numpy()
            edgemap[i] = mask_to_onehot(edgemap[i], seg_logit.shape[1]-1)

            if seg_logit.shape[1]-1 == 1:
                # edgemap[i] = np.expand_dims(edgemap[i], axis=0)
                edgemap[i] = onehot_to_binary_edges(np.expand_dims(edgemap[i], axis=0), 2, seg_logit.shape[1]-1)
            else:
                edgemap[i] = onehot_to_binary_edges(edgemap[i], 2, seg_logit.shape[1]-1)
            
            edge_seg = np.zeros((img_size[2], img_size[3], 1), dtype=np.uint8)
            color_seg = np.zeros((img_size[2], img_size[3], 1), dtype=np.uint8)
            # import ipdb;ipdb.set_trace()
            color_seg[edgemap[i] == 1, :] = 255
            edge_seg[edgepred == 1, :] = 255
            del edgepred
            outputedgegt = "edge/{}_g.png".format(img_metas[0]['ori_filename'].split('.')[0])
            outputedgepred = "edge/{}_p.png".format(img_metas[0]['ori_filename'].split('.')[0])
            cv2.imwrite(outputedgegt, color_seg[:, :, 0])
            cv2.imwrite(outputedgepred, edge_seg[:, :, 0])
  
        
        seg_label = seg_label.squeeze(1)
        
        edgemap = np.expand_dims(edgemap, axis=1)
        edgemap = torch.from_numpy(edgemap).float()
        
        if not isinstance(self.loss_decode, nn.ModuleList):
            losses_decode = [self.loss_decode]
        else:
            losses_decode = self.loss_decode
        for loss_decode in losses_decode:
            if loss_decode.loss_name == 'loss_edgece':
                 loss[loss_decode.loss_name] = loss_decode(
                    edge_logits, 
                    edgemap,
                    weight=seg_weight,
                    ignore_index=self.ignore_index)
            else:
                if loss_decode.loss_name not in loss:
                    loss[loss_decode.loss_name] = loss_decode(
                        seg_logit,
                        seg_label,
                        weight=seg_weight,
                        ignore_index=self.ignore_index)
                else:
                    loss[loss_decode.loss_name] += loss_decode(
                        seg_logit,
                        seg_label,
                        weight=seg_weight,
                        ignore_index=self.ignore_index)
        
        # loss['loss_edge'] = 20 * self.bce2d(edge_logits, edgemap)
        
        loss['acc_seg'] = accuracy(
            seg_logit, seg_label, ignore_index=self.ignore_index)
        return loss
    
    
